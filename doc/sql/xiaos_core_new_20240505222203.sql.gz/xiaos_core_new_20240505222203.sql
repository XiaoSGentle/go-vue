-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: xiaos_core_new
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_api`
--

DROP TABLE IF EXISTS `sys_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_api` (
  `api_code` varchar(255) NOT NULL COMMENT '标记GET::/api',
  `version` int(11) unsigned DEFAULT '0' COMMENT '乐观锁',
  `soft_delete_tag` int(1) unsigned DEFAULT '1' COMMENT '软删除标记',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uuid',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uuid',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '更新者名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_api`
--

LOCK TABLES `sys_api` WRITE;
/*!40000 ALTER TABLE `sys_api` DISABLE KEYS */;
INSERT INTO `sys_api` VALUES ('GET::/api/system/route/pages',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/route/apis',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/route/tree',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/route/roles',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/role/list',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/role/:code',0,1,'2024-05-05 22:12:12',0,0,'','2024-05-05 22:12:12',''),('GET::/api/system/dict/list',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/system/dict/data/list',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/system/log/list',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/system/log/:fileName',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/system/menu/list',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/system/user/list',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/route/getUserRoutes',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/route/getConstantRoutes',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/route/isRouteExist',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/dict',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/dict/:typeCode',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('GET::/api/auth/getUserInfo',0,1,'2024-05-05 22:12:13',0,0,'','2024-05-05 22:12:13',''),('POST::/api/system/dict',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/system/dict/data',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/system/menu',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/system/user',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/system/role',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/auth/refreshToken',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('POST::/api/auth/login',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/role/apis',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/role/menus',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/role/home',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/role/:id',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/dict/data/:id',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/dict/:id',0,1,'2024-05-05 22:12:14',0,0,'','2024-05-05 22:12:14',''),('PUT::/api/system/menu/:id',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('PUT::/api/system/user/:id',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('DELETE::/api/system/dict',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('DELETE::/api/system/dict/data',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('DELETE::/api/system/menu',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('DELETE::/api/system/user',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15',''),('DELETE::/api/system/role',0,1,'2024-05-05 22:12:15',0,0,'','2024-05-05 22:12:15','');
/*!40000 ALTER TABLE `sys_api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_department`
--

DROP TABLE IF EXISTS `sys_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_department` (
  `id` int(11) NOT NULL COMMENT '主键',
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '部门名称',
  `parent_id` int(11) DEFAULT NULL COMMENT '父id',
  `create_by` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uid',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uid',
  `update_by` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '更新者名称',
  `soft_delete_tag` int(11) DEFAULT NULL COMMENT '软删除标记',
  `version` int(11) DEFAULT NULL COMMENT '乐观锁',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='系统部门';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_department`
--

LOCK TABLES `sys_department` WRITE;
/*!40000 ALTER TABLE `sys_department` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_data`
--

DROP TABLE IF EXISTS `sys_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dict_data` (
  `id` int(11) NOT NULL COMMENT '主键',
  `label` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL,
  `type_code` varchar(255) NOT NULL,
  `version` int(11) DEFAULT NULL COMMENT '乐观锁',
  `status` varchar(1) DEFAULT NULL,
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uid',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uid',
  `update_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='字段内容表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_data`
--

LOCK TABLES `sys_dict_data` WRITE;
/*!40000 ALTER TABLE `sys_dict_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_type`
--

DROP TABLE IF EXISTS `sys_dict_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dict_type` (
  `id` int(11) NOT NULL COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '字典名称',
  `code` varchar(255) NOT NULL COMMENT '字典类型',
  `description` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(1) NOT NULL DEFAULT '1' COMMENT '启用状态',
  `version` int(11) DEFAULT NULL COMMENT '乐观锁',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uid',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` varchar(255) DEFAULT NULL COMMENT '更新者',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uid',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='字段类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_type`
--

LOCK TABLES `sys_dict_type` WRITE;
/*!40000 ALTER TABLE `sys_dict_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_gen_table`
--

DROP TABLE IF EXISTS `sys_gen_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_gen_table` (
  `uid` varchar(200) NOT NULL COMMENT '主键',
  `table_name` varchar(200) NOT NULL DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(200) DEFAULT '无' COMMENT '表描述',
  `author_name` varchar(100) DEFAULT '无' COMMENT '作者的名称',
  `low_up_name` varchar(100) DEFAULT '' COMMENT '实体的名称',
  `up_up_name` varchar(60) DEFAULT '' COMMENT '生成模块名',
  `relative_path` varchar(60) DEFAULT NULL COMMENT '相对路径',
  `is_check_token` smallint(1) DEFAULT '1' COMMENT '需要检测是否有Token',
  `is_check_auth` smallint(1) DEFAULT '1' COMMENT '是否鉴权',
  `is_create_log` smallint(1) DEFAULT '1' COMMENT '是否创建日志',
  `remarks` varchar(200) DEFAULT '无' COMMENT '备注信息',
  `version` int(11) DEFAULT NULL COMMENT '乐观锁',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uid',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uid',
  `soft_delete_tag` smallint(255) DEFAULT NULL COMMENT '软删除标记',
  `update_by` varchar(255) DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代码生成业务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_gen_table`
--

LOCK TABLES `sys_gen_table` WRITE;
/*!40000 ALTER TABLE `sys_gen_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_gen_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_gen_table_column`
--

DROP TABLE IF EXISTS `sys_gen_table_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_gen_table_column` (
  `uid` varchar(200) NOT NULL DEFAULT '0' COMMENT '软删除编辑',
  `table_id` varchar(200) DEFAULT NULL COMMENT '表ID',
  `column_up_up_name` varchar(255) DEFAULT NULL COMMENT '字段upup',
  `column_low_up_name` varchar(255) DEFAULT NULL COMMENT '字段lowup',
  `column_name` varchar(255) DEFAULT NULL COMMENT '字段名',
  `column_comment` varchar(200) DEFAULT '' COMMENT '列描述',
  `column_length` varchar(5) DEFAULT '0' COMMENT '列长度',
  `column_type` varchar(100) DEFAULT '' COMMENT 'go类型 ',
  `column_ts_type` varchar(100) DEFAULT NULL COMMENT 'ts类型',
  `is_required` tinyint(1) unsigned DEFAULT '0' COMMENT '是否必填: [1=是, 0=否]',
  `is_base` tinyint(1) unsigned zerofill DEFAULT NULL COMMENT '是否基础字段',
  `is_edit` tinyint(1) unsigned DEFAULT '0' COMMENT '是否编辑字段: [1=是, 0=否]',
  `is_list` tinyint(1) unsigned DEFAULT '0' COMMENT '是否列表字段: [1=是, 0=否]',
  `is_query` tinyint(1) unsigned DEFAULT '0' COMMENT '是否查询字段: [1=是, 0=否]',
  `query_type` varchar(30) DEFAULT 'EQ' COMMENT '查询方式: [等于、不等于、大于、小于、范围]',
  `html_type` varchar(30) DEFAULT '' COMMENT '显示类型: [文本框、文本域、下拉框、复选框、单选框、日期控件]',
  `dict_type` varchar(200) DEFAULT '' COMMENT '字典类型',
  `sort` smallint(5) unsigned DEFAULT '1' COMMENT '排序编号',
  `version` int(11) DEFAULT NULL COMMENT '乐观锁',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uid',
  `create_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uid',
  `soft_delete_tag` tinyint(10) DEFAULT NULL COMMENT '软删除标记',
  `update_by` varchar(255) DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='代码生成字段表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_gen_table_column`
--

LOCK TABLES `sys_gen_table_column` WRITE;
/*!40000 ALTER TABLE `sys_gen_table_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_gen_table_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_menu`
--

DROP TABLE IF EXISTS `sys_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '菜单项名称',
  `router_name` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '路径',
  `redirect` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '重定向地址',
  `parent_id` int(11) unsigned NOT NULL COMMENT '父菜单uuid',
  `component` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '组件名称',
  `props` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '地址参数 u/:id',
  `status` varchar(1) COLLATE utf8mb4_bin NOT NULL DEFAULT '1' COMMENT '是否启用',
  `type` varchar(1) COLLATE utf8mb4_bin NOT NULL DEFAULT '1' COMMENT '目录类型 "1": "目录", "2": "菜单"',
  `meta_icon_type` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '1' COMMENT 'icon类型 0本地 1iconify',
  `meta_order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `meta_constant` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '常量路由',
  `meta_hide_in_menu` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '菜单中隐藏',
  `meta_requires_auth` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要认证',
  `meta_icon` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '元图标',
  `meta_local_icon` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '本地元图标',
  `meta_i18n_key` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '国际化标题',
  `meta_href` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '外部连接',
  `meta_keep_alive` int(1) unsigned NOT NULL DEFAULT '1' COMMENT '缓存该路由',
  `meta_title` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '元数据标题',
  `meta_active_menu` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '激活的菜单键',
  `meta_multi_tab` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '多个标签页',
  `meta_fixed_in_tab` int(1) unsigned DEFAULT NULL COMMENT '标签固定位置',
  `meta_query` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '默认携带参数',
  `version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '乐观锁',
  `soft_delete_tag` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '软删除标记',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uuid',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uuid',
  `create_by` varchar(255) COLLATE utf8mb4_bin DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(255) COLLATE utf8mb4_bin DEFAULT '' COMMENT '更新者名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='系统菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_menu`
--

LOCK TABLES `sys_menu` WRITE;
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` VALUES (1,'403','exception_403','/exception/403','',20,'view.403',0,'1','2','1',0,0,0,1,'ic:baseline-block','','route.403','',1,'403','',0,NULL,'',0,0,'2024-05-02 03:58:36',NULL,NULL,'',NULL,''),(2,'404','exception_404','/exception/404','',20,'view.404',0,'1','2','1',0,1,0,1,'ic:baseline-web-asset-off','','route.404','',1,'404','',0,NULL,'',0,0,'2024-05-02 03:59:00',NULL,NULL,'',NULL,''),(3,'500','exception_500','/exception/500','',20,'view.500',0,'1','2','1',0,1,0,1,'ic:baseline-wifi-off','','route.500','',1,'500','',0,NULL,'',0,0,'2024-05-02 03:59:00',NULL,NULL,'',NULL,''),(4,'关于','about','/about','',0,'layout.base$view.about',0,'1','2','1',10,0,0,1,'fluent:book-information-24-regular','','route.about','',1,'about','',0,NULL,'',0,0,'2024-05-02 03:51:51',NULL,NULL,'',NULL,''),(5,'系统功能','function','/function','',0,'layout.base',0,'1','1','1',6,0,0,1,'icon-park-outline:all-application','','route.function','',1,'function','',0,NULL,'',0,0,'2024-05-02 03:14:32',NULL,NULL,'',NULL,''),(6,'首页','home','/home','',0,'layout.base$view.home',0,'1','2','1',1,0,0,1,'mdi:monitor-dashboard','','route.home','',1,'home','',0,NULL,'',0,0,'2024-05-02 03:46:24',NULL,NULL,'',NULL,''),(11,'系统管理','manage','/manage','',0,'layout.base',0,'1','1','1',9,0,0,1,'carbon:cloud-service-management','','route.manage','',1,'manage','',0,NULL,'',0,0,'2024-05-02 03:14:32',NULL,NULL,'',NULL,''),(12,'菜单管理','manage_menu','/manage/menu','',11,'view.manage_menu',0,'1','2','1',0,0,0,1,'material-symbols:route','','route.manage_menu','',1,'manage_menu','',0,NULL,'',0,0,'2024-05-02 03:22:56',NULL,NULL,'',NULL,''),(13,'角色管理','manage_role','/manage/role','',11,'view.manage_role',0,'1','2','1',0,0,0,1,'carbon:user-role','','route.manage_role','',1,'manage_role','',0,NULL,'',0,0,'2024-05-02 03:22:56',NULL,NULL,'',NULL,''),(14,'用户管理','manage_user','/manage/user','',11,'view.manage_user',0,'1','2','1',0,0,0,1,'ic:round-manage-accounts','','route.manage_user','',1,'manage_user','',0,NULL,'',0,0,'2024-05-02 03:22:56',NULL,NULL,'',NULL,''),(15,'用户详情','manage_user-detail','/manage/user-detail/:id','',11,'view.manage_user-detail',1,'1','2','1',0,0,1,1,'material-symbols:route','','route.manage_menu','',1,'manage_menu','manage_user',0,NULL,'',0,0,'2024-05-02 03:22:56',NULL,NULL,'',NULL,''),(16,'用户主页','user-center','/user-center','',0,'layout.base$view.user-center',0,'1','2','1',0,0,1,1,'ph:user-circle','','route.user-center','',1,'user-center','',0,NULL,'',0,0,'2024-05-02 03:55:45',NULL,NULL,'',NULL,''),(17,'请求','function_request','/function/request','',5,'view.function_request',0,'1','2','1',6,0,0,1,'carbon:network-overlay','','route.function_request','',1,'function_request','',0,NULL,'',0,0,'2024-05-02 03:47:06',NULL,NULL,'',NULL,''),(18,'标签页','function_tab','/function/tab','',5,'view.function_tab',0,'1','2','1',6,0,0,1,'ic:round-tab','','route.function_tab','',1,'function_tab','',0,NULL,'',0,0,'2024-05-02 03:47:06',NULL,NULL,'',NULL,''),(19,'切换权限','function_toggle-auth','/function/toggle-auth','',5,'view.function_toggle-auth',0,'1','2','1',6,0,0,1,'ic:round-construction','','route.function_toggle-auth','',1,'function_toggle-auth','',0,NULL,'',0,0,'2024-05-02 03:47:06',NULL,NULL,'',NULL,''),(20,'异常页','exception','/exception','',0,'layout.base',0,'1','1','1',9,0,0,1,'ant-design:exception-outlined','','route.exception','',1,'','',0,NULL,'',0,0,'2024-05-02 03:59:33',NULL,NULL,'',NULL,''),(21,'测试菜单','test-page','/test-page','',0,'layout.base',0,'1','1','1',8,2,2,1,'carbon:box','','route.test-page','',1,'test-page','',0,0,'',0,0,'2024-05-02 22:33:20',0,0,'','2024-05-02 22:33:20',''),(22,'页面1','test-page_page-one','/test-page/one','',21,'view.test-page_page-one',0,'1','2','1',0,2,2,1,'carbon:bottles-01-dash','','route.test-page_page-one','',1,'test-page_page-one','',0,0,'',0,0,'2024-05-02 22:33:27',0,0,'','2024-05-02 22:33:27',''),(24,'测试菜单2','test-page_page-two','/test-page/two','',21,'view.test-page_page-two',0,'1','2','1',0,2,2,1,'carbon:bluetooth','','route.test-page_page-two','',1,'test-page_page-two','',0,0,'',0,0,'2024-05-03 00:42:39',0,0,'','2024-05-03 00:42:39','');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_oauth2_bind`
--

DROP TABLE IF EXISTS `sys_oauth2_bind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_oauth2_bind` (
  `user_uid` varchar(255) NOT NULL COMMENT '本系统用户的ID',
  `platform_code` varchar(255) DEFAULT NULL COMMENT '三方平台代码',
  `platform_uid` varchar(255) DEFAULT NULL COMMENT '三方平台用户ID',
  PRIMARY KEY (`user_uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_oauth2_bind`
--

LOCK TABLES `sys_oauth2_bind` WRITE;
/*!40000 ALTER TABLE `sys_oauth2_bind` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_oauth2_bind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '名称',
  `code` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '权限标识',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父权限ID',
  `description` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '描述',
  `status` varchar(1) COLLATE utf8mb4_bin DEFAULT '1' COMMENT '角色状态',
  `menu_ids` longtext COLLATE utf8mb4_bin NOT NULL,
  `api_codes` longtext COLLATE utf8mb4_bin NOT NULL,
  `version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '乐观锁',
  `home` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT 'home' COMMENT '首屏',
  `soft_delete_tag` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '软删除标记',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_uid` int(11) DEFAULT NULL COMMENT '更新者uuid',
  `create_uid` int(11) DEFAULT NULL COMMENT '创建者uuid',
  `create_by` varchar(255) COLLATE utf8mb4_bin DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_by` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '更新者名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='系统角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'超级管理员','R_SUPER',0,'超级管理员权限','1','1,4,5,6,11,16,20,21,12,13,14,15,23,2,3,17,18,19,22','GET::/api/system/route/pages,GET::/api/system/route/apis,GET::/api/system/route/tree,GET::/api/system/route/roles,GET::/api/system/role/list,GET::/api/system/role/:code,GET::/api/system/menu/list,GET::/api/system/user/list,POST::/api/system/menu,POST::/api/system/user,POST::/api/system/role,PUT::/api/system/role/apis,PUT::/api/system/role/menus,PUT::/api/system/role/home,PUT::/api/system/role/:id,PUT::/api/system/menu/:id,PUT::/api/system/user/:id,DELETE::/api/system/menu,DELETE::/api/system/user,DELETE::/api/system/role,GET::/api/route/getUserRoutes,GET::/api/route/getConstantRoutes,GET::/api/route/isRouteExist,GET::/api/auth/getUserInfo,POST::/api/auth/refreshToken,POST::/api/auth/login',0,'home',0,'2024-05-03 15:08:02',1,1,'1','2024-05-03 13:42:23','1'),(2,'研发部','RD_PERSON',0,'研发部','1','1,4,5,6,11,16,20,21,12,13,14,15,22,23,2,3,17,18,19','GET::/api/system/route/pages,GET::/api/system/route/apis,GET::/api/system/route/tree,GET::/api/system/route/roles,GET::/api/system/role/list,GET::/api/system/role/:code,GET::/api/system/menu/list,GET::/api/system/user/list,POST::/api/system/menu,POST::/api/system/user,POST::/api/system/role,PUT::/api/system/role/apis,PUT::/api/system/role/menus,PUT::/api/system/role/:id,PUT::/api/system/menu/:id,PUT::/api/system/user/:id,DELETE::/api/system/menu,DELETE::/api/system/user,DELETE::/api/system/role',0,'test-page',0,'2024-05-03 00:19:36',1,1,'1','2024-05-01 19:17:08','1'),(3,'销售专员','SALE_PERSON',0,'销售经理','1','1','GET::/api/system/route/pages,GET::/api/system/route/apis,GET::/api/system/route/tree,GET::/api/system/route/roles,GET::/api/system/role/list,GET::/api/system/role/:code,GET::/api/system/menu/list,GET::/api/system/user/list,POST::/api/system/menu,POST::/api/system/user,POST::/api/system/role,PUT::/api/system/role/apis,PUT::/api/system/role/menus,PUT::/api/system/role/:id,PUT::/api/system/menu/:id,PUT::/api/system/user/:id,DELETE::/api/system/menu,DELETE::/api/system/user,DELETE::/api/system/role',0,'home',0,'2024-05-03 00:20:50',1,1,'1','2024-05-03 00:20:48','1');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `nickname` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '昵称',
  `username` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '用户名',
  `roles` varchar(800) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '角色',
  `password` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '密码',
  `login_attempts` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '尝试登录次数',
  `phone` varchar(32) COLLATE utf8mb4_bin NOT NULL COMMENT '手机',
  `avatar` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '头像',
  `email` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '邮箱',
  `need_change_pwd` int(11) NOT NULL COMMENT '是否需要修改密码',
  `gender` varchar(1) COLLATE utf8mb4_bin NOT NULL DEFAULT '1' COMMENT '性别;1男，0女',
  `last_online_time` datetime DEFAULT NULL COMMENT '上次登录时间',
  `last_cpwd_time` datetime DEFAULT NULL COMMENT '上次改密码时间',
  `user_status` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '用户状态',
  `version` int(11) unsigned NOT NULL COMMENT '乐观锁',
  `soft_delete_tag` int(1) unsigned NOT NULL COMMENT '软删除标记',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  `update_uid` int(11) NOT NULL COMMENT '更新者uuid',
  `create_uid` int(11) NOT NULL COMMENT '创建者uuid',
  `create_by` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_by` varchar(255) COLLATE utf8mb4_bin NOT NULL COMMENT '更新者名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='系统用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'宋超阳','Xiaos','RD_PERSON,SUPER_ADMIN,SALE_PERSON','44b1732ca79fd659db2da175a4786ef7','2024-05-03|0','17712445542','1','xiaosonggentle@gmail.com',1,'1','2024-05-05 21:32:31','2024-05-01 18:15:05','1',1,1,'2024-05-05 21:32:31',1,1,'1','2024-05-03 10:41:10','1'),(2,'周岚林','zhoulanlin','RD_PERSON,SUPER_ADMIN,SALE_PERSON','44b1732ca79fd659db2da175a4786ef7','2024-05-03|0','17727366998','','tets@szreacool.com',1,'1','2024-05-03 16:36:22','2024-05-03 10:56:30','1',0,0,'2024-05-03 16:36:22',0,0,'','2024-05-03 10:56:30','');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-05 22:22:04
